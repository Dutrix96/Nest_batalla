import { Body, Controller, Get, Param, Post, Req, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../auth/jwt-auth.guard";
import { BattlesService } from "./battles.service";
import { CreatePvpLobbyDto } from "./dto/create-pvp-lobby.dto";
import { SelectCharacterDto } from "./dto/select-character.dto";

@Controller("battles")
export class BattlesController {
  constructor(private readonly battlesService: BattlesService) {}

  @UseGuards(JwtAuthGuard)
  @Post("pvp-lobby")
  createPvpLobby(@Req() req: any, @Body() dto: CreatePvpLobbyDto) {
    return this.battlesService.createPvpLobby(req.user.id, dto.opponentUserId);
  }

  @UseGuards(JwtAuthGuard)
  @Post("select-character")
  selectCharacter(@Req() req: any, @Body() dto: SelectCharacterDto) {
    return this.battlesService.selectCharacter(req.user.id, dto.battleId, dto.characterId);
  }

  @UseGuards(JwtAuthGuard)
  @Get(":id")
  getBattle(@Req() req: any, @Param("id") id: string) {
    return this.battlesService.getBattleState(req.user.id, Number(id));
  }
}