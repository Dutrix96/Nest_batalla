export class Battle {}
