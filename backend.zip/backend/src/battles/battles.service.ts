import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { BattleSide } from "@prisma/client";

@Injectable()
export class BattlesService {
  constructor(private prisma: PrismaService) {}

  async createPvpLobby(initiatorUserId: number, opponentUserId: number) {
    if (initiatorUserId === opponentUserId) {
      throw new BadRequestException("No puedes retarte a ti mismo");
    }

    const opp = await this.prisma.user.findUnique({ where: { id: opponentUserId } });
    if (!opp) throw new NotFoundException("Opponent no existe");

    const battle = await this.prisma.battle.create({
      data: {
        mode: "PVP",
        status: "LOBBY",
        initiatorUserId,
        opponentUserId,
        currentTurnSide: "INITIATOR",
        winnerUserId: null,
        winnerSide: null,
      },
      select: { id: true },
    });

    return battle;
  }

  async selectCharacter(userId: number, battleId: number, characterId: number) {
    const battle = await this.prisma.battle.findUnique({
      where: { id: battleId },
      select: {
        id: true,
        mode: true,
        status: true,
        initiatorUserId: true,
        opponentUserId: true,
      },
    });

    if (!battle) throw new NotFoundException("Battle no existe");
    if (battle.mode !== "PVP") throw new BadRequestException("Solo PVP usa lobby");
    if (battle.status !== "LOBBY") throw new BadRequestException("La battle ya no esta en lobby");

    const isInitiator = battle.initiatorUserId === userId;
    const isOpponent = battle.opponentUserId === userId;

    if (!isInitiator && !isOpponent) throw new ForbiddenException("No eres participante");

    const u = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { level: true },
    });
    if (!u) throw new NotFoundException("User no existe");

    const ch = await this.prisma.character.findUnique({ where: { id: characterId } });
    if (!ch) throw new NotFoundException("Character no existe");

    if (ch.requiredLevel > u.level) {
      throw new BadRequestException("No tienes nivel para ese personaje");
    }

    const side: BattleSide = isInitiator ? "INITIATOR" : "OPPONENT";

    await this.prisma.battleParticipant.upsert({
      where: { battleId_side: { battleId, side } },
      update: {
        userId,
        characterId: ch.id,
        hp: ch.maxHp,
        maxHp: ch.maxHp,
        attack: ch.attack,
        specialUsed: false,
      },
      create: {
        battleId,
        side,
        userId,
        characterId: ch.id,
        hp: ch.maxHp,
        maxHp: ch.maxHp,
        attack: ch.attack,
        specialUsed: false,
      },
    });

    const parts = await this.prisma.battleParticipant.findMany({
      where: { battleId },
      select: { side: true },
    });

    const hasInitiator = parts.some((p) => p.side === "INITIATOR");
    const hasOpponent = parts.some((p) => p.side === "OPPONENT");

    if (hasInitiator && hasOpponent) {
      await this.prisma.battle.update({
        where: { id: battleId },
        data: {
          status: "ACTIVE",
          currentTurnSide: "INITIATOR",
          winnerUserId: null,
          winnerSide: null,
        },
      });
    }

    return { ok: true };
  }

  async getBattleState(userId: number, battleId: number) {
    const battle = await this.prisma.battle.findUnique({
      where: { id: battleId },
      include: {
        participants: {
          include: {
            character: true,
            user: true,
          },
        },
      },
    });

    if (!battle) throw new NotFoundException("Battle no existe");

    const isInitiator = battle.initiatorUserId === userId;
    const isOpponent = battle.opponentUserId === userId;

    if (!isInitiator && !isOpponent) throw new ForbiddenException("No eres participante");

    return battle;
  }
}