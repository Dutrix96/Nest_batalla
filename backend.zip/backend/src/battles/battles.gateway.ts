import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from "@nestjs/websockets";
import { Server, Socket } from "socket.io";
import { BattlesService } from "./battles.service";
import { JwtService } from "@nestjs/jwt";

@WebSocketGateway({
  cors: { origin: true, credentials: true },
})
export class BattlesGateway {
  @WebSocketServer()
  server: Server;

  constructor(
    private battlesService: BattlesService,
    private jwt: JwtService
  ) {}

  handleConnection(client: Socket) {
    try {
      const authToken = (client.handshake.auth?.token as string | undefined) ?? "";
      const headerAuth = (client.handshake.headers?.authorization as string | undefined) ?? "";

      const token =
        authToken ||
        (headerAuth.startsWith("Bearer ") ? headerAuth.slice("Bearer ".length) : "");

      if (!token) {
        client.disconnect();
        return;
      }

      const payload: any = this.jwt.verify(token);

      const userId = Number(payload?.sub ?? payload?.id ?? payload?.userId);

      if (!Number.isFinite(userId) || userId <= 0) {
        client.disconnect();
        return;
      }

      (client as any).data.userId = userId;
    } catch {
      client.disconnect();
    }
  }

  private room(battleId: number) {
    return `battle:${battleId}`;
  }

  private getUserId(client: Socket): number | null {
    const id = (client as any).data?.userId ?? null;
    return typeof id === "number" ? id : null;
  }

  @SubscribeMessage("battle:join")
  async onJoin(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { battleId: number }
  ) {
    const battleId = Number(body?.battleId);
    if (!battleId) return;

    client.join(this.room(battleId));

    const userId = this.getUserId(client);
    if (!userId) {
      client.emit("battle:error", { message: "No auth" });
      return;
    }

    const state: any = await this.battlesService.getBattleState(userId, battleId);

    if (state.status === "LOBBY") {
      this.server.to(this.room(battleId)).emit("battle:lobby_state", this.mapLobby(state));
    } else {
      this.server.to(this.room(battleId)).emit("battle:state", state);
    }
  }

  @SubscribeMessage("battle:select_character")
  async onSelectCharacter(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { battleId: number; characterId: number }
  ) {
    const battleId = Number(body?.battleId);
    const characterId = Number(body?.characterId);
    if (!battleId || !characterId) return;

    const userId = this.getUserId(client);
    if (!userId) {
      client.emit("battle:error", { message: "No auth" });
      return;
    }

    await this.battlesService.selectCharacter(userId, battleId, characterId);

    const state: any = await this.battlesService.getBattleState(userId, battleId);

    if (state.status === "LOBBY") {
      this.server.to(this.room(battleId)).emit("battle:lobby_state", this.mapLobby(state));
    } else {
      this.server.to(this.room(battleId)).emit("battle:state", state);
    }
  }

  private mapLobby(battle: any) {
    const ini = battle.participants?.find((p: any) => p.side === "INITIATOR") ?? null;
    const opp = battle.participants?.find((p: any) => p.side === "OPPONENT") ?? null;

    return {
      id: battle.id,
      mode: battle.mode,
      status: battle.status,
      initiatorUserId: battle.initiatorUserId,
      opponentUserId: battle.opponentUserId,
      initiatorPicked: !!ini,
      opponentPicked: !!opp,
      initiatorCharacter: ini?.character ? { id: ini.character.id, name: ini.character.name } : null,
      opponentCharacter: opp?.character ? { id: opp.character.id, name: opp.character.name } : null,
    };
  }
}