import { io, Socket } from "socket.io-client";
import { env } from "../lib/env";

type ServerToClientEvents = {
  "battle:state": (state: any) => void;
  "battle:lobby_state": (state: any) => void;
  "battle:attack": (ev: any) => void;
  "battle:finished": (payload: any) => void;
  "battle:error": (payload: { message: string }) => void;
};

type ClientToServerEvents = {
  "battle:join": (payload: { battleId: number }) => void;
  "battle:select_character": (payload: { battleId: number; characterId: number }) => void;
  "battle:attack": (payload: { battleId: number; special?: boolean }) => void;
};

export type BattleSocket = Socket<ServerToClientEvents, ClientToServerEvents>;

export function createBattleSocket(token: string): BattleSocket {
  return io(env.apiBaseUrl, {
    transports: ["websocket"],
    auth: { token },
  });
}
