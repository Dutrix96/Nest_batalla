import { http } from "../lib/http";

export function apiCreateBattle(
  token: string,
  body:
    | { mode: "PVE"; initiatorCharacterId: number; opponentCharacterId: number }
    | { mode: "PVP"; initiatorCharacterId: number; opponentUserId: number; opponentCharacterId: number }
) {
  return http<any>("/battles", { method: "POST", token, body });
}

export function apiBattle(token: string, id: number) {
  return http<any>(`/battles/${id}`, { token });
}

export function apiMyBattles(token: string) {
  return http<any>("/battles", { token });
}

export function apiAttack(token: string, battleId: number, special: boolean) {
  return http<any>("/battles/attack", { method: "POST", token, body: { battleId, special } });
}

export function apiCreatePvpLobby(token: string, opponentUserId: number) {
  return http<{ id: number }>("/battles/pvp-lobby", {
    method: "POST",
    token,
    body: { opponentUserId },
  });
}

export function apiSelectCharacter(token: string, battleId: number, characterId: number) {
  return http<{ ok: boolean }>("/battles/select-character", {
    method: "POST",
    token,
    body: { battleId, characterId },
  });
}