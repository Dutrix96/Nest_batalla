import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/auth_context";
import { apiCreatePvpLobby } from "../api/battles_api";
import { apiRanking } from "../api/users_api";

type RankUser = {
  id: number;
  email: string;
  level: number;
  xp: number;
  wins: number;
  losses: number;
};

export function PvpSetupPage() {
  const nav = useNavigate();
  const { token, user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [users, setUsers] = useState<RankUser[]>([]);
  const [oppUserId, setOppUserId] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      if (!token) return;
      setLoading(true);
      setErr(null);

      try {
        const ranking = await apiRanking(token);
        const list = (ranking ?? []).filter((u: RankUser) => u.id !== user?.id);
        setUsers(list);
        setOppUserId(list[0]?.id ?? null);
      } catch (e: any) {
        setErr(e?.message || "No se pudo cargar la lista de usuarios");
      } finally {
        setLoading(false);
      }
    })();
  }, [token, user?.id]);

  async function crearLobby() {
    if (!token || !oppUserId) return;

    setErr(null);
    try {
      const res = await apiCreatePvpLobby(token, oppUserId);
      nav(`/app/lobby/${res.id}`);
    } catch (e: any) {
      setErr(e?.message || "No se pudo crear el lobby");
    }
  }

  return (
    <div className="min-h-full">
      <div className="mx-auto max-w-4xl px-4 py-6">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <div className="text-2xl font-semibold">PVP</div>
            <div className="text-sm text-zinc-400">Elige a quien retar. El personaje se elige dentro del lobby.</div>
          </div>
          <button
            className="rounded-xl bg-zinc-800 hover:bg-zinc-700 px-3 py-2 text-sm"
            onClick={() => nav("/app")}
          >
            Volver
          </button>
        </div>

        {err ? (
          <div className="mb-4 rounded-xl border border-red-900/40 bg-red-950/40 px-3 py-2 text-sm text-red-200">
            {err}
          </div>
        ) : null}

        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 p-4">
          <div className="text-sm text-zinc-400">Rival</div>
          <select
            className="mt-2 w-full rounded-xl bg-zinc-950 border border-zinc-800 px-3 py-2 outline-none"
            value={oppUserId ?? ""}
            onChange={(e) => setOppUserId(Number(e.target.value))}
            disabled={loading || users.length === 0}
          >
            {users.length === 0 ? <option value="">No hay usuarios</option> : null}
            {users.map((u) => (
              <option key={u.id} value={u.id}>
                {u.email} · lvl {u.level} · xp {u.xp} · {u.wins}/{u.losses}
              </option>
            ))}
          </select>
          <div className="mt-2 text-xs text-zinc-500">
            Esto crea un lobby PVP. Cuando el rival entre y ambos elijais personaje, empieza la batalla.
          </div>
        </div>

        <button
          className="mt-6 w-full rounded-2xl bg-fuchsia-600 hover:bg-fuchsia-500 text-white px-4 py-3 font-semibold disabled:opacity-50"
          onClick={crearLobby}
          disabled={loading || !oppUserId}
        >
          Crear lobby
        </button>
      </div>
    </div>
  );
}